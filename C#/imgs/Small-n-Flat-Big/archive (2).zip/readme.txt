Iconset: small-n-flat (https://www.iconfinder.com/iconsets/small-n-flat)
Author: Paomedia (https://www.iconfinder.com/paomedia)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2022-06-14